package com.cpgi.lab8.bean;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class DataFile81 {
	FileReader input=null;
	FileWriter output=null;
	public DataFile81(FileReader input, FileWriter output) {
		super();
		this.input = input;
		this.output = output;
	}
	public void run() 
	{
	int i=0,j=0;
	try {
		while((i=input.read())!=-1)
		{output.write((char)i);j++;
		System.out.print((char)i);
		if(j%10==0)
		{
		System.out.println("10 characters are copied");
		Thread.sleep(5000);
		}
		}
		System.out.println("Copying is done");
	} catch (IOException | InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}
	public void start() {
		// TODO Auto-generated method stub
		
	}
	
}