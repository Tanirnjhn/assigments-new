package com.cpgi.lab8.bean;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ProgramFile81 {

	public static void main(String[] args) {
		DataFile81 s=null;
	     try {
			 s=new DataFile81(new FileReader("C:\\Users\\TANEESHA\\Documents\\Taneesha Agrawal\\input.txt"),new FileWriter("C:\\Users\\BRAJMISH\\Documents\\Brajesh Mishra\\output.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      s.start();
	}

}
