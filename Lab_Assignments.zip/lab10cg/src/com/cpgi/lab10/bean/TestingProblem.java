package com.cpgi.lab10.bean;

import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.Test;

public class TestingProblem {


	@Test
	public void checkingForConstructorWorkingOrNot() {
		Date date = new Date(13, 10, 2002);
		String s= "Date is "+13+"/"+10+"/"+2002;
		assertEquals(s, date.toString());
	}
	
	@Test
	public void checkingForSetDayAndGetDay() {
		Date date = new Date(13, 10, 2002);
		assertEquals(11, date.getDay());
	}
	
	@Test
	public void checkingForSetMonthAndGetMonth() {
		Date date = new Date(13, 10, 2002);
		date.setMonth(10);
		assertEquals(10, date.getMonth());
	}

	@Test
	public void checkingForSetYearAndGetYear() {
		Date date = new Date(13, 10, 2002);
		date.setYear(2019);
		assertEquals(2019, date.getYear());
	}
	}


