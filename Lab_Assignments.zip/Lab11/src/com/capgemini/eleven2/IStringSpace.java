package com.capgemini.eleven2;
@FunctionalInterface
public interface IStringSpace {
	public void space(String c);
	

}
