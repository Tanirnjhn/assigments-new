package com.capgemini.eleven1;

public @interface FunctionalInterface {

}
