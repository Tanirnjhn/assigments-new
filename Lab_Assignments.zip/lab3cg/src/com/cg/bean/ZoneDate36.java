package com.cg.bean;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneDate36 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String s1=s.nextLine();
	
			System.out.println(ZonedDateTime.now(ZoneId.of(s1)));

	}

}
