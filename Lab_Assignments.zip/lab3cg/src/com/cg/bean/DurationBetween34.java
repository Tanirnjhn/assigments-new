package com.cg.bean;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DurationBetween34 {

	public static void main(String[] args) {
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner s=new Scanner(System.in);
		
		System.out.print("Enter Date 1 as dd/MM/yy ");
		String i1= s.nextLine();
		LocalDate d1=LocalDate.parse(i1, formatter);
		
		System.out.println("Enter Date 2 as dd/MM/yy ");
		String i2=s.nextLine();
		LocalDate d2=LocalDate.parse(i2, formatter);
		
		Period p=d1.until(d2);
		System.out.println("Days   : " +p.getDays());
		System.out.println("Months : " +p.getMonths());
		System.out.println("Years  : " +p.getYears());

	}

}
