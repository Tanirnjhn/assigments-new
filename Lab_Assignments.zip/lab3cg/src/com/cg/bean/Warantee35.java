package com.cg.bean;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Warantee35 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter date as dd/MM/yyyy");
		String s1=s.nextLine();
		DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Enter warantee period in months and years");
		int months=s.nextInt();
		int years=s.nextInt();
		LocalDate l1=LocalDate.parse(s1, dtf);
		LocalDate d2=l1.plusMonths(months);
		LocalDate d3=d2.plusYears(years);
System.out.println("Expiry Date: "+d3);		
		
	}

}
