package com.cg.eis.bean;

public class Employee {
	private int id;
	private String name;
	private double salary;
	private String dgn;
	private String inschm;
	

 public Employee() {
	super(); 
 }

public Employee(int id, String n, double sal, String d)
   {
	super();
	this.id= id;
	this.name=n;
	this.salary= sal;
	this.dgn= d;
	
    }
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public double getSalary() {
	return salary;
}

public void setSalary(double salary) {
	this.salary = salary;
}

public String getDgn() {
	return dgn;
}

public void setDgn(String dgn) {
	this.dgn = dgn;
}

public String getInschm() {
	return inschm;
}

public void setInschm(String inschm) {
	this.inschm = inschm;
}

}