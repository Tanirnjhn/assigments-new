package com.cg.eis.exception;
import java.lang.Exception;
import java.util.Scanner;

class MyException extends Exception{
	 public MyException(String s)
	 {
		 super(s);
		
	 }
}

public class EmployeeException {

	public static void main(String[] args) 
	{
	 try
	 {
	Scanner sc= new Scanner(System.in);
	 int s1=sc.nextInt();
	  if(s1<3000)
	  {
		  throw new MyException("salary is low");
	  }
	  else
	  {
		  System.out.println("Salary is high");
	  }
	 }
	 catch(MyException e)
	 {
		 System.out.println("caught");
		 System.out.println(e.getMessage());
	 }
	}
}

