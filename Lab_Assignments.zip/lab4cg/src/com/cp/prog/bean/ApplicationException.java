package com.cp.prog.bean;
import java.lang.Exception;
import java.util.Scanner;

class AppException extends Exception
{

 public AppException(String s)
 {
	 super (s);
	 
 }
}
public class ApplicationException
{
	public static void main(String args[])
	{
	 try {	
	
	Scanner s= new Scanner(System.in);
	String s1= s.nextLine();
	String s2= s.nextLine();
	if(s1.equals("") && s2.equals(""))
	{
		throw new AppException("first name and last name are blank");
		
	}
	else 
	{
		System.out.println("All set");
	 }
	 }
	
	catch(AppException e)
	{
		System.out.println("caught");
	
	System.out.println(e.getMessage());
	 }
	
	
	 

}
 
}
	




