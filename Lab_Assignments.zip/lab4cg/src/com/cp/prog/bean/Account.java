package com.cp.prog.bean;


public abstract class Account {

	private long acctnNum;
	protected double balance;
	private String actHol;
	public long getAcctnNum() {
		return acctnNum;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getActHol() {
		return actHol;
	}
	public void setActHol(String actHol) {
		this.actHol = actHol;
	}
	 public void deposit(double d) {
		 balance= balance +d;
		 
	 }
      public abstract void withdraw(double w); 
      public double getBalance() {
       return balance;
      }
      
      @Override
	public String toString() {
		return "Account [acctnNum=" + acctnNum + ", balance=" + balance + ", actHol=" + actHol + "]";
	}
}


      