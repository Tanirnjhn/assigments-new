package com.cpgi.lab7.ui;

public class InvalidAccountNumberException extends Exception {

}
