package com.cpg.prog1.bean;

import java.util.Scanner;

public class StrA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc =new  Scanner(System.in);
		String t =sc.next();
		t= t.concat(t);
		System.out.println(t);
		
		
	}

}
