package com.cpg.prog1.bean;

public class MainClass {


	public int getStudRollno() {
		return studRollno;
	}
	public void setStudRollno(int studrollno) {
		studRollno = studrollno;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studname) {
		studName = studname;
	}
	public float getStudMarks() {
		return studMarks;
	}
	public void setStudMarks(float studmarks) {
		studMarks = studmarks;
	}
	private int studRollno;
	private String studName;
	private float studMarks;
	
}