package com.cpg.prog1.bean;



public class Person24 {
	public Person24()
	{
		super();
	}
	private String firstname;
	private String lastname;
	private char gender;
	private String mobileno;
	
	public Person24(String firstname, String lastname, char gender, String mobileno) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.mobileno = mobileno;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	
}
