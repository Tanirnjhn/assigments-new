package com.cpg.prog1.bean;

public class CheckNum22 {

	public static void main(String args[]) {
		int num;
		num= Integer.parseInt(args[0]);
		if(num>=0)
		{
			System.out.println("no. is positive");
		}
		else {
			System.out.println("no. is negative");
		}
		// TODO Auto-generated method stub

	}

}
